package com.tech.palle.jdbc;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;



public class JdbcFirstExample {

	public static void main(String[] args) {
		A a = new A();
		//a.create();
		
		//a.insert("nikhi",250000);
		//a.insert("pinky",2500);
		//a.insert("milky",250);
		//a.delete(2);
		a.update("rani",1,25000);
		
 }

}
class A {
	public void create(){
		
		Connection cn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/nikhi","root","Nikhi@01yadav");
			 Statement stm = cn.createStatement();
	
			stm.executeUpdate("create table mango(eno int primary key auto_increment, ename varchar(20), esalary int)");
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


public void insert(String name, int salary) {
		PreparedStatement ps = null;
		Connection cn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/nikhi","root","Nikhi@01yadav");
			ps = cn.prepareStatement("insert into mango(ename, esalary) values(?,?)");
			ps.setString(1, name);
			ps.setInt(2, salary);
			ps.executeUpdate();
			
			
			
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				ps.close();
				cn.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}

	}
public void delete(int id) {
	PreparedStatement ps = null;
	Connection cn = null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/nikhi","root","Nikhi@01yadav");
		ps = cn.prepareStatement("delete from mango where eno = ?");
		ps.setInt(1,id);
		ps.executeUpdate();
		
		
	}
	catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			ps.close();
			cn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}
public void update(String name,int id, int salary) {
	PreparedStatement ps = null;
	Connection cn = null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/nikhi","root","Nikhi@01yadav");
		ps = cn.prepareStatement("update mango set ename=?, esalary=? where eno =?");
		ps.setString(1, name);
		ps.setInt(2,salary);
		ps.setInt(3, id);
		ps.executeUpdate();
		
		
	}
	catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
	catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			ps.close();
			cn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}

	
}

